/*ANIL AKBULUT HW1 N-PUZZLES */
/*libraries*/
#include <iostream>
#include <cstdlib>
#include <ctime> 
/* I used this values */
#define MAX_SIZE 9
#define NUM_OF_DIRECT 4
#define RIGHT_DIRCT 6
#define LEFT_DIRCT 4
#define DOWN_DIRCT 2
#define UP_DIRCT 8

using namespace std;/*std function used*/

void init(int puzzle[][MAX_SIZE],int size); /*This function fills puzzles according to size.*/
void print(int puzzle[][MAX_SIZE],int size);/*This function prints puzzles*/
void up(int x,int y,int puzzle[][MAX_SIZE]);/*This function allows puzzled movement to up direction*/
void down(int x,int y,int puzzle[][MAX_SIZE],int size);/*This function allows puzzled movement to down direction*/
void right(int x,int y,int puzzle[][MAX_SIZE],int size);/*This function allows puzzled movement to right direction*/
void left(int x,int y,int puzzle[][MAX_SIZE]);/*This function allows puzzled movement to left direction*/
void game(int x,int y,int puzzle[][MAX_SIZE],int size);/*This function is where the puzzle is played.*/
char rand_cho(int x,int y,int puzzle[][MAX_SIZE],int size);/*This function allows random movement.*/
void check(int x,int y,int size,int *up,int *down,int *left,int *right);
/*This function check which directions to move.*/
char best_move(int x,int y,int puzzle[][MAX_SIZE],int size);/*This function selects the best direction of movement.*/
void init_cmp(int puzzle[][MAX_SIZE],int cmp[][MAX_SIZE],int size);/*This function compares two arrays*/
void sort_best(int arr[],int size);/*This function sorts the array.*/
int cont_finish(int puzzle[][MAX_SIZE],int control[][MAX_SIZE],int size);
/*This function controls the end of the game.*/

void init(int puzzle[][MAX_SIZE],int size){
	int i,j,k=1;
	for(i=0;i<size;i++){ /*The puzzle is filled with elements 0 to 9.*/
		for(j=0;j<size;j++){
			puzzle[i][j]=k;
			k++;
		}
	}
	puzzle[i-1][j-1]=0;
}

void print(int puzzle[][MAX_SIZE],int size){
	int i,j;
	for(i=0;i<size;i++){
		for(j=0;j<size;j++){
			if(puzzle[i][j]!=0){
				if(puzzle[i][j]<10){ /*if the element is smaller than 10 number is written after two space.*/
					cout << puzzle[i][j] << "  "; 
				}
				else cout << puzzle[i][j] << " "; /*if the element is bigger than 10 number 
													is written after one space.*/
			}else{
				cout << "   "; /*if the element is zero, write space*/
			}
		}
		cout << "\n";
	}
}

void up(int x,int y,int puzzle[][MAX_SIZE]){
	int i,j;
	int temp;
	if(x >= 1){ /*if it is moved up, space and number are replaced.*/
		temp = puzzle[x-1][y];
		puzzle[x-1][y] = puzzle[x][y];
		puzzle[x][y] = temp;
	}
}

void down(int x,int y,int puzzle[][MAX_SIZE],int size){
	int i,j;
	int temp;
	if(x+1 < size ){ /*if it is moved down, space and number are replaced.*/
		temp = puzzle[x+1][y];
		puzzle[x+1][y]=puzzle[x][y];
		puzzle[x][y]=temp;
	}
}

void right(int x,int y,int puzzle[][MAX_SIZE],int size){
	int i,j;
	int temp;
	if(y+1 < size ){/*if it is moved right, space and number are replaced.*/
		temp = puzzle[x][y+1];
		puzzle[x][y+1]=puzzle[x][y];
		puzzle[x][y]=temp;
	}
}

void left(int x,int y,int puzzle[][MAX_SIZE]){
	int i,j;
	int temp;
	if(y >= 1){/*if it is moved left, space and number are replaced.*/
		temp = puzzle[x][y-1];
		puzzle[x][y-1] = puzzle[x][y];
		puzzle[x][y] = temp;
	}
}

int cont_finish(int puzzle[][MAX_SIZE],int control[][MAX_SIZE],int size){
	int i,j,cont=1;
	for(i=0;i<size;i++){
		for(j=0;j<size;j++){
			if(!(control[i][j] == puzzle[i][j]))	return 0;
			/*0 is returned if the puzzle is the not same as the finished puzzle.*/
		}
	}
	return 1; /*1 is returned if the puzzle is the same as the finished puzzle.*/
}

void game(int x,int y,int puzzle[][MAX_SIZE],int size){
	char move='S';
	char shuffle;
	char best;
	int count=0,count_moves=0;
	int control[MAX_SIZE][MAX_SIZE];
	init(control,size);
	cout << "Your initial random board is\n";
	while(1){
		switch(move){
			case 'U': up(x,y,puzzle);
					x--;
					break;
			case 'D': down(x,y,puzzle,size);
					x++;
					break;
			case 'L': left(x,y,puzzle);
					y--;
					break;
			case 'R': right(x,y,puzzle,size);
					y++;
					break;
			case 'S':while(count<size*size){ 
						shuffle=rand_cho(x,y,puzzle,size);
						if(shuffle == 'U') x--;
						if(shuffle == 'D') x++;
						if(shuffle == 'L') y--;
						if(shuffle == 'R') y++;
						count++;
					}
					count=0;
					break;
			case 'I':best = best_move(x,y,puzzle,size);
					if(best == 'U') x--;
					if(best == 'D') x++;
					if(best == 'L') y--;
					if(best == 'R') y++;
					break;
			case 'Q':cout << "\nQuit\n";
					  return;		
			default : break;
		}
		if(x >= size) x--;
		if(x < 0) x++;
		if(y >= size) y--;
		if(y < 0) y++;
		if(move=='I') cout <<"Intelligent move chooses "<<best << endl;
		print(puzzle,size);
		cout << "\nYour Move: ";
		cin >> move;
		count_moves++;

		if(cont_finish(puzzle,control,size) == 1){
			cout << "Problem Solved! \n";
			cout << "Total number of moves "<< count_moves << endl;
			return;
		}
	}
}

char best_move(int x,int y,int puzzle[][MAX_SIZE],int size){
	int i,j;
	int move_up,move_down,move_left,move_right;/*these values ​​indicate the status of the move.*/
	int up_count=0,down_count=0,left_count=0,right_count=0; /*these values ​​count the number of correct moves.*/
	int correct[MAX_SIZE][MAX_SIZE];
	int cmp[MAX_SIZE][MAX_SIZE];
	init_cmp(puzzle,cmp,size);
	init(correct,size);
	char back;
	int control;
	int temp[NUM_OF_DIRECT],temp_2[NUM_OF_DIRECT]; /*temporary values ​​are kept here*/

	check(x,y,size,&move_up,&move_down,&move_left,&move_right);/*the moves that can be made are checked.*/
	if(move_up==1){
		up(x,y,cmp);
		for(i=0;i<size;i++){
			for(j=0;j<size;j++){
				if(correct[i][j] == cmp[i][j]) up_count++;
			}
		}
		init_cmp(puzzle,cmp,size);
	}
	temp[0] = up_count;
	if(move_down==1){
		down(x,y,cmp,size);
		for(i=0;i<size;i++){
			for(j=0;j<size;j++){
				if(correct[i][j] == cmp[i][j]) down_count++;
			}
		}
		init_cmp(puzzle,cmp,size);
	}
	temp[1] = down_count;
	
	if(move_left==1){
		left(x,y,cmp);
		for(i=0;i<size;i++){
			for(j=0;j<size;j++){
				if(correct[i][j] == cmp[i][j]) left_count++;
			}
		}
		init_cmp(puzzle,cmp,size);
	}
	temp[2] = left_count;
	
	if(move_right==1){
		right(x,y,cmp,size);
		for(i=0;i<size;i++){
			for(j=0;j<size;j++){
				if(correct[i][j] == cmp[i][j]) right_count++;
			}
		}
		init_cmp(puzzle,cmp,size);
	}
	temp[3] = right_count;	
	
	sort_best(temp,NUM_OF_DIRECT); /*the correct moves are sorted in numbers*/
	i=0;
	if(temp[3] == down_count){
		temp_2[i]=DOWN_DIRCT;
		i++;
	}
	if(temp[3] == up_count){
		temp_2[i]=UP_DIRCT;
		i++;
	}
	if(temp[3] == left_count){
		temp_2[i]=LEFT_DIRCT;
		i++;
	}
	if(temp[3] == right_count){
		temp_2[i]=RIGHT_DIRCT;
		i++;
	}

	control = temp_2[rand()%i]; /*random moves are selected*/
	
	if(control == DOWN_DIRCT && move_down==1){
		down(x,y,puzzle,size);
		back='D';
	}
	else if(control == UP_DIRCT && move_up==1){
		up(x,y,puzzle);
		back='U';
	}
	else if(control == LEFT_DIRCT && move_left==1){
		left(x,y,puzzle);
		back='L';
	}
	else if(control == RIGHT_DIRCT && move_right==1){
		right(x,y,puzzle,size);
		back='R';
	}	
	else{
		back = rand_cho(x,y,puzzle,size);
	}
	return back; /* the moves made are return*/
}

void sort_best(int arr[],int size){
	int i,j,temp;
	for(i=1;i<size;i++){ /*numbers are sorted from small to large*/
		for(j=0; j< size-1;j++){
			if(arr[j] > arr[j+1])
			{
				temp = arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp;
			}
		}
	}
}

void init_cmp(int puzzle[][MAX_SIZE],int cmp[][MAX_SIZE],int size){
	int i,j;
	for(i=0;i<size;i++){ /*compare two arrays*/
		for(j=0;j<size;j++){
			cmp[i][j]=puzzle[i][j];
		}
	}
}

char rand_cho(int x,int y,int puzzle[][MAX_SIZE],int size){
	int move_up,move_down,move_left,move_right;
	int count=0,move;
	int temp[NUM_OF_DIRECT];
	char back;
	
	check(x,y,size,&move_up,&move_down,&move_left,&move_right);
	/*directions is checked*/
	if(move_up == 1){
		temp[count]=UP_DIRCT;
		count++;
	}
	if(move_down==1){
		temp[count]=DOWN_DIRCT;
		count++;		
	}
	if(move_left==1){
		temp[count]=LEFT_DIRCT;
		count++;		
	}
	if(move_right==1){
		temp[count]=RIGHT_DIRCT;
		count++;		
	}

	move = temp[rand()%count]; /*random moves chosen*/
	if(move == UP_DIRCT){
		up(x,y,puzzle);
		back='U';
	} 
	if(move == DOWN_DIRCT){
		down(x,y,puzzle,size);
		back='D';
	}
	if(move == LEFT_DIRCT){
		left(x,y,puzzle);
		back='L';
	}
	if(move == RIGHT_DIRCT){
		right(x,y,puzzle,size);
		back='R';
	}
	return back;
}
void check(int x,int y,int size,int *up,int *down,int *left,int *right){
	if(x>0)	*up=1; /*up direction is controlled*/
	else *up=0;

	if(x<size-1) *down=1;/*down direction is controlled*/
	else *down=0;

	if(y>0) *left=1;/*left direction is controlled*/
	else *left=0;

	if(y<size-1) *right=1;/*right direction is controlled*/
	else *right=0;
}

int main()
{
	int puzzle[MAX_SIZE][MAX_SIZE];
	int size;
	srand(time(0)); /*different numbers keep coming.*/
	cout << "Please enter the problem size\n";
	cin >> size;
	init(puzzle,size);
	game(size-1,size-1,puzzle,size);
	return 0;
}